<?xml version="1.0" encoding="UTF-8"?>
<tileset name="LD40" tilewidth="8" tileheight="8" tilecount="50" columns="5">
 <image source="tileMap.png" width="40" height="80"/>
</tileset>
